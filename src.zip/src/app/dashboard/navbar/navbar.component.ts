import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { GreetingComponent } from '../../greeting/greeting.component';

@Component({
  selector: 'app-navbar',
  standalone: true,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  imports: [CommonModule, RouterModule, GreetingComponent],
})
export class NavbarComponent {
  token = localStorage.getItem('token');
  tokenData = this.token ? this.parseJwt(this.token) : null;

  showAdminDropdown = false;
  showTrainsDropdown = false;
  showProfileDropdown = false;

  constructor(private router: Router) {
    console.log('NavbarComponent initialized');
    console.log('Token data:', this.tokenData);
  }

  handleLogout() {
    console.log('Logout initiated');
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
    console.log('User redirected to /login after logout');
  }

  parseJwt(token: string) {
    try {
      console.log('Parsing JWT token');
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const parsedToken = JSON.parse(window.atob(base64));
      console.log('Token parsed successfully:', parsedToken);
      return parsedToken;
    } catch (e) {
      console.error('Failed to parse token:', e);
      return null;
    }
  }

  toggleDropdown(type: string) {
    console.log(`Toggling dropdown: ${type}`);
    if (type === 'admin') {
      this.showAdminDropdown = !this.showAdminDropdown;
      console.log('Admin dropdown visibility:', this.showAdminDropdown);
    } else if (type === 'trains') {
      this.showTrainsDropdown = !this.showTrainsDropdown;
      console.log('Trains dropdown visibility:', this.showTrainsDropdown);
    } else if (type === 'profile') {
      this.showProfileDropdown = !this.showProfileDropdown;
      console.log('Profile dropdown visibility:', this.showProfileDropdown);
    }
  }
}
