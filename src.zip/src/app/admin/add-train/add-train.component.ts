import { CommonModule } from '@angular/common';
import {
  HttpClient,
  HttpClientModule,
  HttpHeaders,
} from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-train',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './add-train.component.html',
  styleUrls: ['./add-train.component.scss'],
})
export class AddTrainComponent {
  train = {
    trainNumber: '',
    source: '',
    destination: '',
    departureTime: '',
    arrivalTime: '',
    fare: '',
    totalSeats: '',
  };

  error: string | null = null;
  successMessage: string | null = null;

  constructor(private http: HttpClient) {}

  async handleSubmit(): Promise<void> {
    this.error = null;
    this.successMessage = null;

    // Validation
    if (!/^\d{5}$/.test(this.train.trainNumber)) {
      this.error = 'Train number must be exactly 5 digits.';
      return;
    }
    if (isNaN(+this.train.fare) || +this.train.fare <= 0) {
      this.error = 'Fare must be a positive number.';
      return;
    }
    if (isNaN(+this.train.totalSeats) || +this.train.totalSeats <= 0) {
      this.error = 'Total seats must be a positive whole number.';
      return;
    }

    const trainData = {
      ...this.train,
      fare: parseFloat(this.train.fare),
      totalSeats: parseInt(this.train.totalSeats, 10),
    };

    // Get token from localStorage or use another method to retrieve it
    const token = localStorage.getItem('token');

    if (!token) {
      this.error = 'Authorization token is missing';
      return;
    }

    // Add Authorization header
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    try {
      const response: any = await this.http
        .post('http://localhost:8080/Trains/addDetails', trainData, { headers })
        .toPromise();
      this.successMessage = `Train added successfully: ${response.trainNumber}`;
      this.train = {
        trainNumber: '',
        source: '',
        destination: '',
        departureTime: '',
        arrivalTime: '',
        fare: '',
        totalSeats: '',
      };
    } catch (error) {
      console.error('Error adding train:', error);
      this.error = 'Failed to add train. Please try again later.';
    }
  }
}
