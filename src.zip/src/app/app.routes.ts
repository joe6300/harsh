import { Routes } from '@angular/router';
import { AddTrainComponent } from './admin/add-train/add-train.component';
import { DeleteTrainsComponent } from './admin/delete-trains/delete-trains.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './login/register.component';
import { DashPageComponent } from './pages/dash-page.component';
import { HomeComponent } from './pages/home.component';
import { ProfileComponent } from './profile/profile.component';

import { TrainSearchComponent } from './trains/train-search/train-search.component';

import { TransactionComponent } from './profile/transactions/transactions.component';
import { AllTrainsComponent } from './trains/all-trains/all-trains.component';
import { TrainManagerComponent } from './trains/train-manager/train-manager.component';

import { TrainBookingComponent } from './profile/train-booking/train-booking.component';
import { MyBookiingsComponent } from './profile/my-bookings/my-bookings.component';
import { MyBookComponent } from './profile/my-book/my-book.component';


export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashPageComponent,
    children: [
      { path: 'add-trains', component: AddTrainComponent },
      { path: 'delete-trains', component: DeleteTrainsComponent },
      { path: 'profile', component: ProfileComponent },

      

      {path: 'transactions', component: TransactionComponent},
      {path: 'all-trains', component: AllTrainsComponent},
      {path: 'train-manager', component: TrainManagerComponent},

      {path:'train-booking',component:TrainBookingComponent},

      {path:'my-book',component:MyBookComponent},
      {path:'my-bookiings',component:MyBookiingsComponent},

      
    ],
  },
  { path: '**', redirectTo: '', pathMatch: 'full' },
];
