export function parseJwt(token: string | null): any {
  if (!token) return null; // Handle null token case

  try {
    const base64Url = token.split('.')[1]; // Extract payload part
    if (!base64Url) throw new Error('Invalid token structure'); // Ensure payload exists

    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/'); // Convert to standard Base64
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((char) => `%${`00${char.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join('')
    ); // Decode Base64 safely

    return JSON.parse(jsonPayload); // Convert to JSON object
  } catch (error) {
    console.error('Error parsing JWT:', error);
    return null; // Return null if any error occurs
  }
}
