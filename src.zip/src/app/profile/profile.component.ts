import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  user: any = null;
  token: string | null = localStorage.getItem('token');
  loading: boolean = true;
  errorMessage: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    console.log('Token on init:', this.token); // Log the token

    if (this.token) {
      const tokenData = this.parseJwt(this.token);
      console.log('Parsed token data:', tokenData); // Log parsed token data

      // Refactor the condition to handle 0 as a valid ID
      if (tokenData && tokenData.id !== undefined) {
        console.log('User ID extracted from token:', tokenData.id); // Log extracted user ID
        this.fetchUserData(tokenData.id);
      } else {
        console.error('Invalid token or missing user ID in token');
        this.errorMessage = 'Invalid token or missing user data in the token.';
        this.loading = false;
      }
    } else {
      console.error('Token not found in localStorage');
      this.errorMessage = 'Token not found. Please log in again.';
      this.loading = false;
    }
  }

  // Parse the JWT token to extract user data (like ID)
  private parseJwt(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const parsedData = JSON.parse(window.atob(base64));
      console.log('Decoded JWT:', parsedData); // Log the decoded JWT to verify the data
      return parsedData;
    } catch (error) {
      console.error('Error parsing JWT:', error);
      return null;
    }
  }

  // Fetch the user data from the backend API
  private fetchUserData(userId: string): void {
    const headers = { Authorization: `Bearer ${this.token}` };
    console.log('Request Headers:', headers);
    console.log('Fetching data for user ID:', userId); // Log the user ID being fetched

    this.http
      .get(`http://localhost:8080/User/retrieve/${userId}`, { headers })
      .subscribe({
        next: (data) => {
          console.log('User data fetched:', data); // Log the full response from the API
          if (data) {
            this.user = data;
            this.loading = false;
          } else {
            console.warn('No data returned for user ID:', userId);
            this.errorMessage = 'No user data found for the provided ID.';
            this.loading = false;
          }
        },
        error: (error) => {
          console.error('Error fetching user data:', error); // Log the error details
          this.errorMessage =
            'Error loading user data. Please try again later.';
          this.loading = false;
        },
      });
  }
}
