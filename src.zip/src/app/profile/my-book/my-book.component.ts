import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';

interface Booking {
  ticketId: string;
  bookingDate: string;
  status: string;
  origin: string;
  destination: string;
  seatNumber: string;
  price: number;
}

@Component({
  selector: 'app-my-book',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './my-book.component.html',
  styleUrls: ['./my-book.component.scss']
})
export class MyBookComponent implements OnInit {
  bookings: Booking[] = [];
  error: string | null = null;
  noBookingsMessage: string | null = null;
  isLoading: boolean = false;
  private baseUrl = 'http://localhost:8080/Bookings/user';
  private token: string | null = localStorage.getItem('token');
  userId: string | null = null;

  constructor(private http: HttpClient) {
    if (this.token) {
      const tokenData = this.parseJwt(this.token);
      if (tokenData && tokenData.id) {
        this.userId = tokenData.id;
      } else {
        this.error = 'User ID not found. Please log in again.';
      }
    } else {
      this.error = 'Please log in to view your bookings.';
    }
  }

  ngOnInit(): void {
    if (this.userId) {
      this.fetchUserBookings();
    }
  }

  private parseJwt(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const parsedData = JSON.parse(window.atob(base64));
      return parsedData;
    } catch (error) {
      console.error('Error parsing JWT:', error);
      return null;
    }
  }

  fetchUserBookings(): void {
    this.isLoading = true;
    this.error = null;
    this.noBookingsMessage = null;

    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.token}`);

    this.http.get<Booking[]>(`${this.baseUrl}/getUserTickets/${this.userId}`, { headers })
      .subscribe({
        next: (response) => {
          if (response && Array.isArray(response) && response.length > 0) {
            this.bookings = response;
          } else {
            this.noBookingsMessage = 'No bookings found for your account.';
            this.bookings = [];
          }
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error fetching bookings:', error);
          this.isLoading = false;
          if (error.status === 404) {
            this.noBookingsMessage = 'No bookings found.';
          } else {
            this.error = error.error?.message || 'Failed to fetch bookings. Please try again later.';
          }
          this.bookings = [];
        }
      });
  }

  handleCancelBooking(ticketId: string): void {
    const confirmCancel = window.confirm(`Are you sure you want to cancel ticket ${ticketId}?`);
    if (!confirmCancel) return;

    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.token}`);

    this.http.put(`${this.baseUrl}/cancel/${ticketId}`, {}, { headers })
      .subscribe({
        next: () => {
          this.bookings = this.bookings.map(booking =>
            booking.ticketId === ticketId
              ? { ...booking, status: 'Cancelled' }
              : booking
          );
          alert('Booking cancelled successfully.');
        },
        error: (error) => {
          console.error('Error canceling booking:', error);
          alert(error.error?.message || 'Failed to cancel booking. Please try again.');
        }
      });
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  getStatusColor(status: string): string {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return 'text-green-600';
      case 'cancelled':
        return 'text-red-600';
      case 'pending':
        return 'text-yellow-600';
      default:
        return 'text-gray-600';
    }
  }
}