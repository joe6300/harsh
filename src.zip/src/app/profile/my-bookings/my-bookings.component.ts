import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-bookings.component.html',
  styleUrls: ['./my-bookings.component.scss']
})
export class MyBookiingsComponent implements OnInit {
  bookings: any[] = [];
  error: string | null = null;
  noBookingsMessage: string | null = null;
  private baseUrl = 'http://localhost:8080/Bookings/user';
  private token: string | null = localStorage.getItem('token');
  userId: string | null = null;

  constructor(private http: HttpClient) {
    // Parse token and get userId on initialization
    if (this.token) {
      const tokenData = this.parseJwt(this.token);
      if (tokenData && tokenData.id) {
        this.userId = tokenData.id;
      } else {
        this.error = 'User ID not found. Please log in again.';
      }
    }
  }

  ngOnInit(): void {
    if (this.userId) {
      this.fetchUserBookings();
    }
  }

  private parseJwt(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const parsedData = JSON.parse(window.atob(base64));
      return parsedData;
    } catch (error) {
      console.error('Error parsing JWT:', error);
      return null;
    }
  }

  fetchUserBookings(): void {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`
    });

    this.http.get<any[]>(`${this.baseUrl}/getUserTickets/${this.userId}`, { headers })
      .subscribe({
        next: (response) => {
          if (response && Array.isArray(response) && response.length > 0) {
            this.bookings = response;
            this.noBookingsMessage = null;
          } else {
            this.noBookingsMessage = 'No bookings available for this user.';
            this.bookings = [];
          }
        },
        error: (error) => {
          console.error('Error fetching bookings:', error);
          if (error.status === 404) {
            this.noBookingsMessage = error.error || 'No bookings found.';
          } else {
            this.error = error.error?.message || 'Failed to fetch bookings.';
          }
        }
      });
  }

  handleCancelBooking(ticketId: string): void {
    const confirmCancel = window.confirm(`Are you sure you want to Cancel the ticket ${ticketId}?`);
    if (!confirmCancel) return;

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`
    });

    this.http.put(`${this.baseUrl}/cancel/${ticketId}`, {}, { headers })
      .subscribe({
        next: () => {
          this.bookings = this.bookings.map(booking =>
            booking.ticketId === ticketId
              ? { ...booking, status: 'Cancelled' }
              : booking
          );
          alert(`Booking ${ticketId} canceled successfully.`);
        },
        error: (error) => {
          console.error('Error canceling booking:', error);
          alert('Failed to cancel booking. Please try again.');
        }
      });
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleString();
  }
}