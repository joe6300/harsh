import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-train-manager',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule,RouterModule],
  templateUrl: './train-manager.component.html',
  styleUrls: ['./train-manager.component.scss'],
})
export class TrainManagerComponent implements OnInit {
  trainNumber:string = '';
  source: string = '';
  destination: string = '';
  trains: any[] = [];
  error: string | null = null;
  token: string = '';
  private baseUrl = 'http://localhost:8080/Trains/user';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.token = localStorage.getItem('token') || '';
    this.fetchAllTrains();
  }

  fetchAllTrains(): void {
    console.log('Fetching all trains...');
    const headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });
    this.http.get(`${this.baseUrl}/getAll`, { headers }).subscribe(
      (data: any) => {
        console.log('All trains:', data);
        this.trains = data;
      },
      (error) => {
        console.error('Error fetching all trains:', error);
        this.error = 'Failed to load trains.';
      }
    );
  }

  searchTrains(): void {
    console.log('Searching trains...');
    if (this.source && this.destination) {
      const headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });
      const params = { source: this.source, destination: this.destination };
      this.http
        .get(`${this.baseUrl}/searchByStation`, { headers, params })
        .subscribe(
          (data: any) => {
            console.log('Search results:', data);
            this.trains = data;
            this.error = null; // Clear previous errors
          },
          (error) => {
            console.error('Error searching trains:', error);
            this.error = 'No trains found.';
            this.trains = [];
          }
        );
    } else {
      console.warn('Source or destination is missing.');
      alert('Please enter both source and destination.');
    }
  }
}
