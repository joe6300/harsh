import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TrainsService } from '../trains.service';

@Component({
  selector: 'app-train-results',
  standalone: true,
  imports: [CommonModule, HttpClientModule, RouterModule],
  templateUrl: './train-results.component.html',
  styleUrls: ['./train-results.component.css'],
})
export class TrainResultsComponent implements OnInit {
  @Input() source!: string;
  @Input() destination!: string;
  trains: any[] = [];
  error: string | null = null;

  constructor(private trainsService: TrainsService) {}

  ngOnInit(): void {
    const token = localStorage.getItem('token') || '';
    this.trainsService
      .searchTrains(token, this.source, this.destination)
      .subscribe(
        (data) => {
          console.log('Search results:', data);
          this.trains = data;
        },
        (error) => {
          console.error('Error fetching search results:', error);
          this.error = 'No trains found.';
        }
      );
  }
}
