import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-trains',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './all-trains.component.html',
  styleUrls: ['./all-trains.component.scss'],
})
export class AllTrainsComponent implements OnInit {
  trains: any[] = [];
  error: string | null = null;
  loading: boolean = true;
  private baseUrl = 'http://localhost:8080/Trains/user';
  private token: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.token = localStorage.getItem('token') || '';
    this.fetchAllTrains();
  }

  fetchAllTrains(): void {
    console.log('Fetching all trains...');
    const headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });

    this.http.get(`${this.baseUrl}/getAll`, { headers }).subscribe(
      (data: any) => {
        console.log('All trains:', data);
        // Map the response to ensure it includes necessary fields
        this.trains = data.map((train: any) => ({
          trainNumber: train.trainNumber || 'N/A',
          source: train.source || 'Unknown',
          destination: train.destination || 'Unknown',
          fare: train.fare || 'N/A',
          arrivalTime: train.arrivalTime || 'N/A',
          
        }));
        this.error = null; // Clear error if data is successfully loaded
      },
      (error) => {
        console.error('Error fetching all trains:', error);
        this.error = 'Failed to load trains.';
        this.trains = [];
      },
      () => {
        this.loading = false; // Mark loading as false after completion
      }
    );
  }
}
