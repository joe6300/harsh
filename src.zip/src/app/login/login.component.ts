import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http'; // Correct module
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [FormsModule, RouterModule, HttpClientModule, CommonModule], // Corrected imports
})
export class LoginComponent {
  user: string = '';
  password: string = '';
  message: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  handleEvent() {
    if (!this.user || !this.password) {
      this.message = 'Input cannot be empty';
      return;
    }

    const authRequest = { username: this.user, password: this.password };

    this.http
      .post('http://localhost:8080/User/login', authRequest, {
        responseType: 'text',
      })
      .subscribe(
        (response: string) => {
          // Expecting a string (e.g., JWT or message)
          localStorage.setItem('token', response);
          this.message = 'Login successful!';
          this.router.navigate(['/dashboard']);
        },
        (error) => {
          if (error.error) {
            // Display a meaningful error message
            this.message =
              'Error: ' +
              (typeof error.error === 'string'
                ? error.error
                : JSON.stringify(error.error));
          } else {
            this.message = 'Error: Unable to reach the server';
          }
        }
      );

    this.user = '';
    this.password = '';
  }
}
