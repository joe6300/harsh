import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  imports: [FormsModule, RouterModule, HttpClientModule, CommonModule], // Updated import
})
export class RegisterComponent {
  user: string = '';
  password: string = '';
  mail: string = '';
  address: string = '';
  phone: string = '';
  message: string = '';

  constructor(private http: HttpClient) {} // Added HttpClient injection

  handleEvent() {
    if (!this.user || !this.password || !this.mail || !this.phone) {
      this.message = 'Input cannot be empty';
      return;
    }

    const phonePattern = /^\d{10}$/;
    if (!phonePattern.test(this.phone)) {
      alert('Phone number must be exactly 10 digits');
      return;
    }

    const passwordPattern =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{5,8}$/;
    if (!passwordPattern.test(this.password)) {
      alert("Password Doesn't Meet Standards");
      return;
    }

    const authRequest = {
      username: this.user,
      email: this.mail.toLowerCase(),
      password: this.password,
      address: this.address,
      phoneno: this.phone,
    };

    this.http
      .post('http://localhost:8080/User/register', authRequest)
      .subscribe(
        () => {
          this.message = 'User added successfully!';
        },
        (error: any) => {
          // Added type to error
          this.message = error.error
            ? `Error: ${error.error}`
            : 'Error: Unable to reach the server';
        }
      );

    this.user = '';
    this.mail = '';
    this.password = '';
    this.address = '';
    this.phone = '';
  }
}
